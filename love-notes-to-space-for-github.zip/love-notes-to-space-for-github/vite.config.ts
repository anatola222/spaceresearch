import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { VitePWA } from "vite-plugin-pwa";

export default defineConfig({
  // Lovable runs projects on port 8080
  server: { host: "::", port: 8080 },
  plugins: [
    react(),
    VitePWA({
      registerType: "autoUpdate",
      includeAssets: ["icons/*.png"],
      manifest: {
        name: "Love Notes to Space",
        short_name: "Love Notes",
        description: "The research and designs behind Anatola Araba's film of Mars.",
        display: "fullscreen",
        orientation: "any",
        background_color: "#150B26",
        theme_color: "#150B26",
        icons: [
          { src: "icons/icon-192.png", sizes: "192x192", type: "image/png" },
          { src: "icons/icon-512.png", sizes: "512x512", type: "image/png", purpose: "any maskable" },
        ],
      },
      workbox: {
        // Everything, including every image and the film, is saved for offline use.
        globPatterns: ["**/*.{js,css,html,png,jpg,jpeg,webp,svg,mp4,webm}"],
        maximumFileSizeToCacheInBytes: 500 * 1024 * 1024,
        runtimeCaching: [
          {
            urlPattern: /^https:\/\/fonts\.(googleapis|gstatic)\.com\/.*/,
            handler: "CacheFirst",
            options: { cacheName: "fonts", expiration: { maxEntries: 30 }, cacheableResponse: { statuses: [0, 200] } },
          },
          {
            urlPattern: ({ url }) => url.pathname.startsWith("/images/") || url.pathname.startsWith("/video/"),
            handler: "CacheFirst",
            options: { cacheName: "media", rangeRequests: true, cacheableResponse: { statuses: [0, 200] } },
          },
        ],
      },
    }),
  ],
});
