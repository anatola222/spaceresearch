"""Make small web copies of the artwork for the app.

Usage:  python3 scripts/optimize_images.py "<folder with the original PNGs>"
Writes public/images/thumb/<name>.webp (480px) and public/images/full/<name>.webp (1600px)
for every image referenced in src/data/board.ts. Spaces in source names become underscores,
so "eco space lora colored-12.png" becomes eco_space_lora_colored-12.
"""
import os, re, sys
from PIL import Image

root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
src_dir = sys.argv[1]
board = open(os.path.join(root, "src/data/board.ts")).read()
wanted = set(re.findall(r'file:\s*"([^"]+)"', board))
by_name = {f.replace(" ", "_"): f for f in os.listdir(src_dir)}
for name in sorted(wanted):
    if name not in by_name:
        print("missing:", name); continue
    base = os.path.splitext(name)[0]
    im = Image.open(os.path.join(src_dir, by_name[name])).convert("RGB")
    for folder, size, q in (("thumb", 480, 72), ("full", 1600, 78)):
        c = im.copy(); c.thumbnail((size, size))
        c.save(os.path.join(root, "public/images", folder, base + ".webp"), "WEBP", quality=q, method=6)
    print("ok:", name)
