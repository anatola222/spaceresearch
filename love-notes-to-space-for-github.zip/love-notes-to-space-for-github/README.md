# Love Notes to Space

*mycelium mars and afro astra to infinity and beyond*

Interactive exhibit by Anatola Araba (R3imagine Story Lab): the research and designs behind SPACESEED.

## Run it locally
    npm install
    npm run dev          # http://localhost:8080 (also on your network, for testing on an iPad)

`http://localhost:8080/#overview` skips the opening and shows the whole sky.

## Edit the content
Everything visitors see is in `src/data/board.ts`: the title, the opening line, clusters, cards and connections.
- Add a card: copy one card object and change it.
- Hide a card: `published: false`, or leave `whatItIs` empty.
- Add an image: put the file in `public/images/` and add `{ file: "name.png", credit: "…" }` to a card.
  For smaller, faster copies, run `python3 scripts/optimize_images.py "<folder of originals>"`.
- The film: upload it as `public/video/mars-film.mp4`.

## Install on the iPad / touchscreen
Deploy (Lovable, Netlify…) and open the https link once online. Everything is then saved for offline use.
iPad: Share > Add to Home Screen, then use Guided Access to lock it to the app.
Visitor notes are stored on that device only. Hold the "Write a love note…" title for 5 seconds to clear them.
