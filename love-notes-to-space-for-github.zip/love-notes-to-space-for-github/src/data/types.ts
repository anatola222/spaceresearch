export type CardImage = { file: string; credit?: string };

export type Card = {
  id: string;
  title: string;
  cluster: string;
  images: CardImage[];
  whatItIs: string;
  myThought?: string;
  starThread?: string;
  backToEarth?: string;
  annotation?: string; // short handwritten note with an arrow pointing at the card
  sourceCredit?: string; // shown prominently under the title (used for Star Knowledge cards)
  published?: boolean; // default true
  video?: string; // only used by the central film card
};

export type Connection = { from: string; to: string; why: string; pulse?: boolean };

export type Cluster = { id: string; label: string };
