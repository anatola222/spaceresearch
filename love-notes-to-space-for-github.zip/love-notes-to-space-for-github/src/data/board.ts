// ─────────────────────────────────────────────────────────────────────────────
//  LOVE NOTES TO SPACE: everything visitors see lives in this file.
//
//  • Add a card: copy one object in `cards` and change it.
//  • Hide a card: set `published: false` (or leave `whatItIs` empty).
//  • Images go in /public/images/. Refer to them by file name here.
//  • Add a connection: add one line to `connections`.
// ─────────────────────────────────────────────────────────────────────────────
import type { Card, Cluster, Connection } from "./types";

export const APP_TITLE = "Love Notes to Space";
export const ARTIST = "Anatola Araba";
export const STUDIO = "R3imagine Story Lab";

// Logos in the bottom-left corner, in this order (files live in /public/brand/).
export const LOGOS = [
  { src: "/brand/r3imagine-story-lab.webp", alt: "Reimagine Story Lab" },
  { src: "/brand/anatola.webp", alt: "Anatola, creativity for good" },
];

export const TEXT = {
  introLine: "We didn't come to the stars. We came from them.",
  zoomPrompt: "pinch to zoom out and see what inspired this story ✦",
  whatItIs: "What it is",
  starThread: "Our celestial thread",
  backToEarth: "Back to Earth",
  connectedTo: "Connected to",
  signature: "— Anatola ✦",
  home: "Home",
  credits: "Credits",
  creditsTitle: "Image credits",
  close: "Close",
  notesTitle: "Write a love note to where you came from",
  notesPlaceholder: "Dear stars…",
  notesSubmit: "Send it to the sky ✦",
  notesCleared: "notes cleared",
};

// Visitor notes: max characters per note, and how many are shown at once.
export const NOTES = { maxLength: 140, maxShown: 40 };

// Seconds without a touch before the sky starts drifting on its own.
export const IDLE_SECONDS = 90;

// The central node. Its `cluster` must be CENTER_CLUSTER.
export const CENTER_CLUSTER = "center";
export const CENTER_CARD_ID = "the-film";

// The first cluster sits closest to the film. The rest circle around it.
export const clusters: Cluster[] = [
  { id: "we-came-from-stars", label: "We Came From the Stars" },
  { id: "body-in-space", label: "The Body in Space" },
  { id: "delight-in-orbit", label: "Delight in Orbit" },
  { id: "braids-as-maps", label: "Braids as Maps" },
  { id: "grown-architecture", label: "Grown Architecture" },
  { id: "domes", label: "Domes" },
  { id: "gardens-in-space", label: "Gardens in Space" },
  { id: "mars-sky", label: "The Mars Sky" },
  { id: "crystal-planet", label: "Crystal Planet" },
  { id: "astronaut-designs", label: "My Astronaut Designs" },
];

export const cards: Card[] = [
  // ── Center ────────────────────────────────────────────────────────────────
  {
    id: "the-film",
    title: "SPACESEED",
    cluster: CENTER_CLUSTER,
    video: "/video/spaceseed-ecology-clip-ii.mp4",
    images: [],
    whatItIs:
      "Inspired by Octavia Butler's unpublished Parable of the Trickster. When the president of humanity's first city on Mars is overthrown, a quiet 16-year-old astrobotanist must overcome her homesickness to lead the settlement into a regenerative future. Everything on this board is what inspired it.",
  },

  // ── We Came From the Stars ────────────────────────────────────────────────
  {
    id: "star-stuff",
    title: "Star Stuff",
    cluster: "we-came-from-stars",
    published: false, // replaced by Iridescent Clouds for now
    images: [],
    whatItIs:
      "Almost every element in the human body heavier than hydrogen, including the carbon in our cells, the oxygen we breathe, the calcium in our bones, and the iron in our blood, was forged inside stars and scattered across space when those stars died.",
    myThought:
      "Many Indigenous peoples have long seen their human origins in the stars. We have always had celestial origins.",
    starThread: "Science is only now catching up to what many peoples always knew.",
    backToEarth: "You are not separate from the cosmos. You are the cosmos, living on Earth.",
  },
  {
    id: "iridescent-clouds",
    title: "Iridescent Clouds",
    cluster: "we-came-from-stars",
    images: [
      { file: "iridescent-cloud-curiosity.png", credit: "NASA/JPL-Caltech/MSSS" },
      { file: "iridescent-clouds.png" },
      { file: "iridescent-clouds-ii.png" },
    ],
    whatItIs:
      "Just after sunset on January 27, 2023, NASA's Curiosity rover photographed a feather-shaped iridescent cloud drifting over Mars. Iridescence appears when sunlight passes through cloud particles that are all nearly the same size, splitting the light into soft colors like mother-of-pearl.",
    myThought:
      "Iridescent clouds are even rarer than a rainbow, but they remind me of one. They're just so beautiful. Oh, the wonder of planets!",
  },
  {
    id: "star-knowledge",
    title: "Star Knowledge",
    cluster: "we-came-from-stars",
    images: [],
    whatItIs: "", // hidden until filled in with a specific tradition and its source
    sourceCredit: "",
  },

  // ── The Body in Space ─────────────────────────────────────────────────────
  {
    id: "floating-water",
    title: "Floating Water",
    cluster: "body-in-space",
    images: [
      { file: "eco_space_lora_colored-12.png", credit: "NASA / CSA" },
      { file: "eco_space_lora_colored-13.png", credit: "NASA / CSA" },
    ],
    whatItIs:
      "In microgravity, surface tension pulls water into floating spheres. On a space station, water doesn't pour. It drifts.",
    myThought:
      "Water floats in space, so on a space station it becomes floating orbs. To wash your hands, you'd open your hand in front of an orb.",
    starThread:
      "Scientists believe much of Earth's water may have been delivered by asteroids and comets. The water in your hands may be older than the Sun.",
    annotation: "water floats here!",
  },
  {
    id: "exercise",
    title: "Exercise Against Weightlessness",
    cluster: "body-in-space",
    images: [{ file: "eco_space_lora_colored-15.png", credit: "NASA" }],
    whatItIs:
      "Astronauts exercise about two hours a day. Without gravity pulling on them, bones and muscles weaken, and bone mass can drop around 1% per month.",
    myThought: "Astronauts have to work out every day so their bones don't atrophy.",
    starThread:
      "The calcium in your bones was forged inside ancient stars. Keeping our bones strong in space is caring for stardust.",
    backToEarth:
      "Every step we take on Earth is quietly keeping our bones alive. Gravity is a gift we never notice.",
  },

  {
    id: "cimon",
    title: "CIMON",
    cluster: "body-in-space",
    images: [
      { file: "cimon-iss.png", credit: "Airbus" },
      { file: "cimon-mars-garden.png" },
    ],
    whatItIs:
      "CIMON (Crew Interactive MObile companioN) is a floating, AI-powered robot assistant about the size of a medicine ball. It was built by Airbus and IBM for the German Aerospace Center (DLR). It flew to the International Space Station in 2018 to help astronaut Alexander Gerst with experiments, and its successor CIMON-2 followed in 2019.",
    myThought:
      "I learned about CIMON at the Museum of the Future at SXSW, where astronauts were speaking. I always ask a lot of questions, so I raised my hand and asked about AI in space, and they told me about CIMON!",
  },

  // ── Delight in Orbit ──────────────────────────────────────────────────────
  {
    id: "stations-wonder",
    title: "Stations Made for Wonder",
    cluster: "delight-in-orbit",
    published: false,
    images: [
      { file: "eco_space_lora_colored-22.png", credit: "Vast" },
      { file: "eco_space_lora_colored-25.png", credit: "Vast" },
      { file: "eco_space_lora_colored-26.png", credit: "Vast" },
    ],
    whatItIs: "Space station interiors designed for rest, gathering, and beauty, not just survival.",
    myThought:
      "Hilary Coe, creative director at Vast, imagines space stations that are luxurious and beautiful, mirroring a future where space travel includes delight, wonder, and awe.",
  },
  {
    id: "joy-in-space",
    title: "Joy in Space",
    cluster: "delight-in-orbit",
    published: false,
    images: [
      { file: "eco_space_lora_colored-62.png", credit: "Aurelia Institute" },
      { file: "eco_space_lora_colored-64.png", credit: "Aurelia Institute" },
      { file: "eco_space_lora_colored-69.png", credit: "Aurelia Institute" },
      { file: "eco_space_lora_colored-70.png", credit: "Aurelia Institute" },
    ],
    whatItIs: "The Aurelia Institute designs space architecture that centers joy, community, and beauty.",
    myThought:
      "The Aurelia Institute explores joy in space, imagining a space world that gives back to Earth.",
  },

  // ── Braids as Maps ────────────────────────────────────────────────────────
  {
    id: "cornrows",
    title: "Cornrows to the Cosmos",
    cluster: "braids-as-maps",
    images: [
      { file: "eco_space_lora_colored-33.png" },
      { file: "eco_space_lora_colored-34.png" },
      { file: "eco_space_lora_colored-35.png" },
      { file: "eco_space_lora_colored-36.png" },
    ],
    whatItIs:
      "Oral tradition from San Basilio de Palenque, Colombia, tells of enslaved Africans in the 1600s braiding escape routes to freedom into cornrow patterns. The knowledge was passed down body to body.",
    myThought: "Today, how might Black hair reimagine our relationship to the cosmos?",
    starThread: "Braids once carried maps to freedom. What maps to the stars might they carry now?",
  },

  // ── Grown Architecture ────────────────────────────────────────────────────
  {
    id: "mycelium",
    title: "Mycelium Habitats",
    cluster: "grown-architecture",
    images: [{ file: "eco_space_lora_colored-42.png" }, { file: "eco_space_lora_colored-43.png" }],
    whatItIs:
      "NASA-funded research explores growing habitats from mycelium, the root network of fungi, on Mars, instead of shipping heavy building materials from Earth.",
    myThought: "Using mycelium to grow eco space architecture.",
  },

  // ── Domes ─────────────────────────────────────────────────────────────────
  {
    id: "domes-win",
    title: "Why Domes Win in Space",
    cluster: "domes",
    images: [{ file: "eco_space_lora_colored-46.png" }, { file: "eco_space_lora_colored-57.png" }],
    whatItIs:
      "A Mars habitat holds pressurized air pushing outward against near-vacuum. Curved domes spread that stress evenly, which is why domes and spheres win.",
    myThought:
      "Geodesic domes, inspired by Buckminster Fuller and the book 'How to Live on Mars,' show how dome structures are better in space.",
  },
  {
    id: "shell-mycelium",
    title: "Shell Mycelium",
    cluster: "domes",
    published: false,
    images: [{ file: "eco_space_lora_colored-56.png", credit: "Shell Mycelium" }],
    whatItIs: "A dome structure designed to be grown and to decompose back into the earth.",
  },

  // ── Gardens in Space ──────────────────────────────────────────────────────
  {
    id: "growing-without-soil",
    title: "Growing Without Soil",
    cluster: "gardens-in-space",
    images: [
      { file: "eco_space_lora_colored-121.png", credit: "NASA" },
      { file: "eco_space_lora_colored-122.png" },
      { file: "eco_space_lora_colored-125.png" },
      { file: "eco_space_lora_colored-126.png" },
    ],
    whatItIs:
      "Martian soil contains toxic perchlorates, and there's no soil at all in orbit, so space farming is hydroponic: roots grow in water and nutrients instead of dirt. Vertical farms will be key to feeding people off-world.",
    myThought: "In space we have to grow without soil, so hydroponic gardens and vertical farms will be key.",
    backToEarth:
      "The same vertical farms could feed crowded cities on Earth using a fraction of the land and water.",
  },
  {
    id: "space-gardens",
    title: "Space Gardens",
    cluster: "gardens-in-space",
    published: false,
    images: [
      { file: "eco_space_lora_colored-63.png", credit: "Aurelia Institute" },
      { file: "eco_space_lora_colored-65.png", credit: "Aurelia Institute" },
    ],
    whatItIs: "Gardens designed to grow in orbit, bringing living green into space architecture.",
    myThought: "Space gardens imagining a space world for Earth.",
  },

  // ── The Mars Sky ──────────────────────────────────────────────────────────
  {
    id: "blue-sunsets",
    title: "Blue Sunsets",
    cluster: "mars-sky",
    images: [
      { file: "eco_space_lora_colored-92.png", credit: "NASA/JPL, Spirit rover, 2005" },
      { file: "eco_space_lora_colored-93.png" },
      { file: "eco_space_lora_colored-94.png" },
      { file: "eco_space_lora_colored-95.png" },
      { file: "eco_space_lora_colored-101.png" },
      { file: "eco_space_lora_colored-102.png" },
      { file: "eco_space_lora_colored-103.png" },
      { file: "eco_space_lora_colored-104.png" },
      { file: "eco_space_lora_colored-105.png" },
      { file: "eco_space_lora_colored-106.png" },
    ],
    whatItIs:
      "Sunsets on Mars really are blue. Fine Martian dust scatters light so the sky glows blue around the setting sun, the reverse of Earth.",
    myThought:
      "Learning this made me see our orange sunsets as a gift. Earth paints its evenings in fire, and I'd never noticed how rare that is.",
    starThread: "Every sunset, on any planet, is light from our own star meeting the sky it made possible.",
    backToEarth: "Look up tonight. Our sunset colors exist only because of our atmosphere.",
  },
  {
    id: "sulfur-crystals",
    title: "Sulfur Crystals",
    cluster: "crystal-planet",
    images: [
      { file: "curiosity-sulfur-crystals.png", credit: "NASA/JPL-Caltech/MSSS" },
      { file: "crystal-mars-rocks.png", credit: "NASA/JPL-Caltech" },
    ],
    whatItIs: "In 2024, NASA's Curiosity rover cracked open a rock and found pure yellow sulfur crystals inside.",
    myThought:
      "Mars isn't a dead rock in the sky. It's a sacred crystal, holding its history inside like a geode.",
    starThread:
      "Crystals and bodies are built from the same star-forged elements. Mars and our bodies are made of the same ancient stardust.",
  },
  {
    id: "crystal-planet",
    title: "Crystal Planet",
    cluster: "crystal-planet",
    images: [{ file: "crystal-mars.png" }],
    whatItIs:
      "In 2016, NASA's Curiosity rover found tridymite in Gale Crater: a rare crystal made of silica, the same chemical as quartz. Years earlier, the Spirit rover uncovered soil of nearly pure silica. Mars holds crystals inside its stones.",
    myThought:
      "We see planets as giant rocks in the sky. But what if they are giant crystals? NASA rovers found quartz crystals on Mars. It's proof planets should be treated with ceremony and reverence.",
  },
  {
    id: "marsbees",
    title: "Marsbees",
    cluster: "mars-sky",
    images: [
      { file: "marsbee-concept.png", credit: "NASA / C. Kang" },
      { file: "marsbee-garden.png" },
    ],
    whatItIs:
      "Earth bees couldn't fly on Mars because the air is only about 1% as dense as ours. NASA-funded researchers imagined robotic bees with oversized wings.",
    myThought: "A bee's wings are perfectly sized for Earth's air. Our bodies and this planet were made to match.",
    backToEarth: "Pollinators are made for this exact planet. Protecting them is protecting a perfect match.",
  },
  {
    id: "rovers-at-dusk",
    title: "Rovers at Dusk",
    cluster: "mars-sky",
    images: [
      { file: "eco_space_lora_colored-107.png", credit: "NASA/JPL-Caltech" },
      { file: "eco_space_lora_colored-108.png", credit: "NASA/JPL-Caltech" },
    ],
    whatItIs:
      "NASA's rovers are our eyes on Mars. Perseverance landed in Jezero Crater in 2021 to search for signs of ancient life.",
  },

  // ── My Astronaut Designs ──────────────────────────────────────────────────
  {
    id: "future-suits",
    title: "Ecological Space Suit Designs",
    cluster: "astronaut-designs",
    images: [
      { file: "worldseed-hero.png", credit: "Anatola Araba" },
      { file: "eco_space_lora_colored-128.png", credit: "Anatola Araba" },
      { file: "eco_space_lora_colored-129.png", credit: "Anatola Araba" },
      { file: "eco_space_lora_colored.png", credit: "Anatola Araba" },
    ],
    whatItIs: "Original spacesuit designs by the artist.",
    myThought: "My astronaut designs.",
  },
];

export const connections: Connection[] = [
  { from: "star-stuff", to: "exercise", why: "The calcium in our bones came from the stars.", pulse: true },
  { from: "star-stuff", to: "floating-water", why: "Water, too, traveled across space to reach us." },
  { from: "star-stuff", to: "sulfur-crystals", why: "Mars and our bodies share the same stardust." },
  { from: "star-stuff", to: "star-knowledge", why: "Two ways of knowing, one truth.", pulse: true },
  { from: "star-knowledge", to: "cornrows", why: "Knowledge carried through the body and through generations." },
  { from: "floating-water", to: "domes-win", why: "In space, the round shape is the natural one: water becomes spheres, habitats become domes." },
  { from: "exercise", to: "marsbees", why: "Our bones and bees' wings were both made for this planet.", pulse: true },
  { from: "stations-wonder", to: "exercise", why: "The body's needs and the spirit's needs, side by side." },
  { from: "joy-in-space", to: "space-gardens", why: "Gardens as joy, not just food." },
  { from: "cornrows", to: "future-suits", why: "Hair, helmets, and heritage. Carrying our stories into space." },
  { from: "cornrows", to: "mycelium", why: "Braids and root networks. Maps and knowledge woven through connection." },
  { from: "mycelium", to: "domes-win", why: "Grown architecture and dome geometry, two answers to building on Mars." },
  { from: "mycelium", to: "shell-mycelium", why: "A structure that is both grown and a dome." },
  { from: "shell-mycelium", to: "domes-win", why: "Fuller's geometry, grown instead of built." },
  { from: "mycelium", to: "growing-without-soil", why: "Life that builds its own ground." },
  { from: "space-gardens", to: "growing-without-soil", why: "Two ways of keeping green alive off-world." },
  { from: "marsbees", to: "growing-without-soil", why: "No gardens without pollinators." },
  { from: "blue-sunsets", to: "sulfur-crystals", why: "Mars keeps surprising us with color." },
  { from: "rovers-at-dusk", to: "blue-sunsets", why: "Every Martian sunset we've ever seen came to us through a rover's eyes." },
  { from: "rovers-at-dusk", to: "sulfur-crystals", why: "Rovers are how we found the crystals inside Mars." },
];
