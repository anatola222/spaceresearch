// Builds the sky: positions every visible card, constellation and line.
// Everything is computed from visible content, so hidden cards never leave gaps.
import type { Edge, Node } from "@xyflow/react";
import type { Card, Cluster, Connection } from "../data/types";
import { boardCards, centerCard, visibleClusters, visibleConnections } from "./content";
import { between, rng } from "./random";

export const CARD_W = 240;
export const CARD_H = 180;
export const FILM_W = 480;
export const FILM_H = 270;

const SPACING = 330; // distance between neighbouring cards inside a constellation
const GOLDEN = Math.PI * (3 - Math.sqrt(5));
const REVEAL_STEP = 450; // ms between constellations fading in

export type CardData = { card: Card; rotation: number; revealDelay: number };
export type FilmData = { card: Card };
export type LabelData = { cluster: Cluster; nodeIds: string[]; revealDelay: number };
export type FrameData = { radius: number; seed: number; revealDelay: number };
export type DoodleData = { kind: "star" | "heart" | "question"; seed: number; revealDelay: number };
export type EdgeData = { why: string; pulse?: boolean };

type Placed = { cluster: Cluster; cards: { card: Card; x: number; y: number }[]; radius: number; cx: number; cy: number };

// Relaxed sunflower scatter, re-centred on the constellation's middle.
const scatter = (cluster: Cluster, cards: Card[]): Placed => {
  const r = rng(cluster.id);
  const pts = cards.map((card, k) => {
    const d = SPACING * Math.sqrt(k);
    const a = k * GOLDEN + between(r, -0.3, 0.3);
    return { card, x: d * Math.cos(a) + between(r, -28, 28), y: d * Math.sin(a) + between(r, -28, 28) };
  });
  const mx = pts.reduce((s, p) => s + p.x, 0) / pts.length, my = pts.reduce((s, p) => s + p.y, 0) / pts.length;
  pts.forEach((p) => { p.x -= mx; p.y -= my; });
  const radius = Math.max(...pts.map((p) => Math.hypot(p.x, p.y))) + 210;
  return { cluster, cards: pts, radius, cx: 0, cy: 0 };
};

export const buildBoard = () => {
  const placed = visibleClusters.map((cl) => scatter(cl, boardCards.filter((c) => c.cluster === cl.id)));
  const filmR = Math.hypot(FILM_W, FILM_H) / 2 + 80;

  // The first cluster ("We Came From the Stars") sits closest to the film.
  const [inner, ...outer] = placed;
  if (inner) { inner.cx = 0; inner.cy = -(filmR + inner.radius + 40); }
  const maxOuter = Math.max(0, ...outer.map((p) => p.radius));
  const gap = 90;
  const circ = outer.reduce((s, p) => s + 2 * p.radius + gap, 0);
  const R = Math.max(
    circ / (2 * Math.PI),
    filmR + maxOuter + 120,
    inner ? Math.abs(inner.cy) + inner.radius + maxOuter + gap : 0,
  );
  const jitter = rng("ring");
  let acc = 0;
  const firstShare = outer.length ? ((2 * outer[0].radius + gap) / circ) * 2 * Math.PI : 0;
  outer.forEach((p) => {
    const share = ((2 * p.radius + gap) / circ) * 2 * Math.PI;
    // start just past the inner cluster at the top, so the ring reads as a loose loop
    const a = -Math.PI / 2 + Math.PI / Math.max(3, outer.length) + acc + share / 2 - firstShare / 2 + between(jitter, -0.05, 0.05);
    const rr = R * between(jitter, 0.97, 1.08);
    p.cx = rr * Math.cos(a); p.cy = rr * Math.sin(a);
    acc += share;
  });

  const nodes: Node[] = [];
  const edges: Edge[] = [];

  if (centerCard)
    nodes.push({ id: centerCard.id, type: "film", position: { x: 0, y: 0 }, width: FILM_W, height: FILM_H, data: { card: centerCard } satisfies FilmData });

  placed.forEach((p, i) => {
    const revealDelay = i * REVEAL_STEP;
    const r = rng(p.cluster.id + ":rot");
    nodes.push({
      id: `frame:${p.cluster.id}`, type: "frame", position: { x: p.cx, y: p.cy }, zIndex: -1,
      width: p.radius * 2, height: p.radius * 2,
      selectable: false, focusable: false, style: { pointerEvents: "none" },
      data: { radius: p.radius, seed: i + 3, revealDelay } satisfies FrameData,
    });
    p.cards.forEach(({ card, x, y }) =>
      nodes.push({
        id: card.id, type: "card", position: { x: p.cx + x, y: p.cy + y }, width: CARD_W, height: CARD_H,
        data: { card, rotation: between(r, -2, 2), revealDelay } satisfies CardData,
      }),
    );
    nodes.push({
      id: `label:${p.cluster.id}`, type: "label", position: { x: p.cx, y: p.cy - p.radius - 6 },
      data: { cluster: p.cluster, nodeIds: [`frame:${p.cluster.id}`, ...p.cards.map((c) => c.card.id)], revealDelay } satisfies LabelData,
    });
    if (centerCard)
      edges.push({ id: `l:${p.cluster.id}`, source: `label:${p.cluster.id}`, target: centerCard.id, type: "clusterLink", focusable: false });

    // Sparse doodles, outside the constellation's circle so they never cover content.
    if (i % 2 === 1) {
      const out = Math.atan2(p.cy, p.cx);
      const kinds: DoodleData["kind"][] = ["star", "heart", "question"];
      [0.55, -0.6].slice(0, i % 4 === 1 ? 2 : 1).forEach((off, j) => {
        let a = out + off;
        if (Math.abs(Math.sin(a) + 1) < 0.25) a += 0.8; // keep clear of the label at the top
        nodes.push({
          id: `doodle:${p.cluster.id}:${j}`, type: "doodle",
          position: { x: p.cx + (p.radius + 55) * Math.cos(a), y: p.cy + (p.radius + 55) * Math.sin(a) },
          selectable: false, focusable: false, style: { pointerEvents: "none" },
          data: { kind: kinds[(i + j) % 3], seed: i * 7 + j, revealDelay } satisfies DoodleData,
        });
      });
    }
  });

  visibleConnections.forEach((k: Connection) =>
    edges.push({
      id: `c:${k.from}:${k.to}`, source: k.from, target: k.to, type: "constellation",
      data: { why: k.why, pulse: k.pulse } satisfies EdgeData,
    }),
  );

  // Visitor notes live at the outer edge of the sky.
  const notesR = R + maxOuter + 420;
  const notesAngle = Math.PI / 2 + Math.PI / Math.max(3, outer.length) / 2;
  const notesCenter = { x: notesR * Math.cos(notesAngle), y: notesR * Math.sin(notesAngle) };
  nodes.push({ id: "notes", type: "notes", position: notesCenter, data: { revealDelay: placed.length * REVEAL_STEP } });

  return { nodes, edges, notesCenter, clusterCount: placed.length };
};

// Where the n-th visitor note floats, around the notes title.
export const notePosition = (center: { x: number; y: number }, id: string, n: number) => {
  const r = rng(id);
  const a = n * GOLDEN + between(r, -0.3, 0.3);
  const d = 230 + 95 * Math.sqrt(n) + between(r, -20, 20);
  return { x: center.x + d * Math.cos(a), y: center.y + d * Math.sin(a) };
};
