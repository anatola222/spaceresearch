// Images are referenced by their original file name in board.ts.
// Small web copies live in /images/thumb and /images/full (see scripts/optimize_images.py).
// If there's no web copy yet, the original in /images/ is used instead.
const base = (file: string) => file.replace(/\.[^.]+$/, "");

export const imageSources = (file: string, size: "thumb" | "full") => [
  `/images/${size}/${base(file)}.webp`,
  ...(size === "thumb" ? [`/images/full/${base(file)}.webp`] : []),
  `/images/${file}`,
];
