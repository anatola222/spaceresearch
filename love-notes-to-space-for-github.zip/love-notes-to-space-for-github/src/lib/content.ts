// Applies the content rules to board.ts. Components only ever see visible content.
import { cards, clusters, connections, CENTER_CARD_ID, CENTER_CLUSTER } from "../data/board";
import type { Card } from "../data/types";

const isVisible = (c: Card) => c.published !== false && c.whatItIs.trim() !== "";
const clusterIds = new Set(clusters.map((c) => c.id));

export const centerCard = cards.find((c) => c.id === CENTER_CARD_ID && isVisible(c));

// Cards on the board (not the film). A card whose cluster isn't listed in board.ts is skipped.
export const boardCards = cards.filter(
  (c) => isVisible(c) && c.cluster !== CENTER_CLUSTER && clusterIds.has(c.cluster),
);

const visibleIds = new Set([...boardCards.map((c) => c.id), ...(centerCard ? [centerCard.id] : [])]);
export const cardById = new Map(
  [...boardCards, ...(centerCard ? [centerCard] : [])].map((c) => [c.id, c] as const),
);

export const visibleClusters = clusters.filter((cl) => boardCards.some((c) => c.cluster === cl.id));

export const visibleConnections = connections.filter(
  (k) => k.from !== k.to && visibleIds.has(k.from) && visibleIds.has(k.to),
);

export const connectedTo = (id: string): Card[] =>
  visibleConnections
    .filter((k) => k.from === id || k.to === id)
    .map((k) => cardById.get(k.from === id ? k.to : k.from)!)
    .filter((c, i, a) => a.indexOf(c) === i);

export const has = (s?: string) => !!s && s.trim() !== "";

// Every visible image credit, with the cards it appears on.
export const credits: { credit: string; titles: string[] }[] = (() => {
  const m = new Map<string, string[]>();
  for (const c of [...(centerCard ? [centerCard] : []), ...boardCards])
    for (const img of c.images)
      if (has(img.credit)) {
        const t = m.get(img.credit!.trim()) ?? [];
        if (!t.includes(c.title)) t.push(c.title);
        m.set(img.credit!.trim(), t);
      }
  return [...m].map(([credit, titles]) => ({ credit, titles }));
})();
