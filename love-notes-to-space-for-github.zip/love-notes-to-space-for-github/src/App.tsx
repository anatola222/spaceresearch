import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { MiniMap, ReactFlow, ReactFlowProvider, useReactFlow, type Node, type Viewport } from "@xyflow/react";
import { APP_TITLE, IDLE_SECONDS, LOGOS, NOTES, TEXT } from "./data/board";
import { cardById } from "./lib/content";
import { buildBoard, notePosition, FILM_W } from "./lib/layout";
import { BoardCtx, type ActiveEdge } from "./components/context";
import { nodeTypes } from "./components/nodes";
import { edgeTypes } from "./components/edges";
import StarField from "./components/StarField";
import DetailPanel from "./components/DetailPanel";
import { CreditsPanel, Intro, NoteComposer } from "./components/Panels";

type Note = { id: string; text: string };
const NOTES_KEY = "love-notes-to-space:notes";
const loadNotes = (): Note[] => { try { return JSON.parse(localStorage.getItem(NOTES_KEY) || "[]"); } catch { return []; } };
const saveNotes = (n: Note[]) => { try { localStorage.setItem(NOTES_KEY, JSON.stringify(n)); } catch { /* storage unavailable */ } };

const MOVE_MS = 600;
const board = buildBoard();
const startZoom = () => Math.min(1.5, (innerWidth * 0.72) / FILM_W);
const startViewport = (): Viewport => ({ x: innerWidth / 2, y: innerHeight / 2, zoom: startZoom() });

function Board() {
  const rf = useReactFlow();
  // index.html#overview skips the opening and shows the whole sky (handy for setup and testing)
  const overview = location.hash === "#overview";
  const [introDone, setIntroDone] = useState(overview);
  const [showPrompt, setShowPrompt] = useState(false);
  const [openCard, setOpenCard] = useState<string | null>(null);
  const [panel, setPanel] = useState<"credits" | "notes" | null>(null);
  const [activeEdge, setActiveEdge] = useState<ActiveEdge>(null);
  const [notes, setNotes] = useState<Note[]>(loadNotes);
  const [toast, setToast] = useState<string | null>(null);

  const nodes = useMemo<Node[]>(() => {
    const shown = notes.slice(-NOTES.maxShown);
    return [
      ...board.nodes,
      ...shown.map((n, i) => ({
        id: `note:${n.id}`, type: "visitorNote", position: notePosition(board.notesCenter, n.id, i),
        selectable: false, focusable: false, data: { text: n.text, delay: (i * 730) % 5000 },
      })),
    ];
  }, [notes]);

  // ── camera helpers ──
  const goHome = useCallback(() => rf.fitView({ duration: MOVE_MS, padding: 0.08 }), [rf]);
  const goToCard = useCallback((id: string) => {
    const n = rf.getInternalNode(id);
    if (!n) return;
    const w = n.measured.width ?? 0, h = n.measured.height ?? 0;
    rf.setCenter(n.internals.positionAbsolute.x + w / 2, n.internals.positionAbsolute.y + h / 2, { zoom: 1.1, duration: MOVE_MS });
  }, [rf]);

  // ── opening ──
  const finishIntro = useCallback(() => { setIntroDone(true); setShowPrompt(true); }, []);
  const onMove = useCallback((_: unknown, vp: Viewport) => {
    if (vp.zoom < startZoom() * 0.7) setShowPrompt(false);
  }, []);

  // ── idle: drift slowly across the sky, ending on the film ──
  const drift = useRef<{ cancelled: boolean } | null>(null);
  const stopDrift = useCallback(() => {
    if (!drift.current) return;
    drift.current.cancelled = true; drift.current = null;
    rf.setViewport(rf.getViewport(), { duration: 0 });
  }, [rf]);
  const startDrift = useCallback(async () => {
    setOpenCard(null); setPanel(null); setActiveEdge(null);
    const token = { cancelled: false }; drift.current = token;
    const wait = (ms: number) => new Promise((r) => setTimeout(r, ms));
    const labels = board.nodes.filter((n) => n.type === "label");
    const offset = Math.floor(Math.random() * Math.max(1, labels.length));
    const stops = Array.from({ length: Math.min(4, labels.length) }, (_, i) => labels[(offset + i) % labels.length]);
    for (const s of stops) {
      if (token.cancelled) return;
      rf.setCenter(s.position.x, s.position.y + 300, { zoom: 0.5, duration: 9000 });
      await wait(9000);
    }
    if (token.cancelled) return;
    rf.setCenter(0, 0, { zoom: startZoom(), duration: 9000 });
    await wait(9000);
    if (!token.cancelled) { drift.current = null; setShowPrompt(true); }
  }, [rf]);

  useEffect(() => {
    if (!introDone) return;
    let t = 0;
    const poke = () => { stopDrift(); clearTimeout(t); t = window.setTimeout(startDrift, IDLE_SECONDS * 1000); };
    const evs = ["pointerdown", "wheel", "keydown", "touchstart"] as const;
    evs.forEach((e) => addEventListener(e, poke, { passive: true }));
    poke();
    return () => { clearTimeout(t); evs.forEach((e) => removeEventListener(e, poke)); };
  }, [introDone, startDrift, stopDrift]);

  // ── visitor notes ──
  const addNote = (text: string) => {
    const next = [...notes, { id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6), text }];
    setNotes(next); saveNotes(next); setPanel(null);
  };
  const clearNotes = useCallback(() => {
    setNotes([]); saveNotes([]); setToast(TEXT.notesCleared);
    setTimeout(() => setToast(null), 2500);
  }, []);
  const ctx = useMemo(
    () => ({ revealed: introDone, activeEdge, openNotes: () => setPanel("notes"), clearNotes }),
    [introDone, activeEdge, clearNotes],
  );

  const card = openCard ? cardById.get(openCard) : undefined;

  return (
    <BoardCtx.Provider value={ctx}>
      <StarField />
      <ReactFlow
        className={introDone ? "revealed" : ""}
        nodes={nodes}
        edges={board.edges}
        nodeTypes={nodeTypes}
        edgeTypes={edgeTypes}
        nodeOrigin={[0.5, 0.5]}
        defaultViewport={startViewport()}
        minZoom={0.06}
        maxZoom={2.5}
        nodesDraggable={false}
        nodesConnectable={false}
        elementsSelectable={false}
        zoomOnDoubleClick={false}
        proOptions={{ hideAttribution: true }}
        onMove={onMove}
        onInit={() => { if (overview) setTimeout(() => rf.fitView({ padding: 0.08 }), 50); }}
        onNodeClick={(_, n) => {
          setActiveEdge(null);
          if (n.type === "card" || n.type === "film") setOpenCard(n.id);
          if (n.type === "label") rf.fitView({ nodes: (n.data as { nodeIds: string[] }).nodeIds.map((id) => ({ id })), duration: MOVE_MS, padding: 0.12 });
        }}
        onEdgeClick={(e, edge) => {
          if (edge.type !== "constellation") return;
          const p = rf.screenToFlowPosition({ x: e.clientX, y: e.clientY });
          setActiveEdge(activeEdge?.id === edge.id ? null : { id: edge.id, x: p.x, y: p.y });
        }}
        onPaneClick={() => setActiveEdge(null)}
      >
        <MiniMap
          position="bottom-right"
          pannable
          zoomable
          className="minimap"
          bgColor="#150B26"
          maskColor="rgba(21,11,38,0.55)"
          maskStrokeColor="#C9CAD6"
          nodeColor={(n) => (n.type === "card" || n.type === "film" ? "#5FE3D0" : "transparent")}
          nodeStrokeColor={(n) => (n.type === "frame" ? "rgba(201,202,214,0.5)" : "transparent")}
          nodeStrokeWidth={20}
          nodeBorderRadius={400}
        />
      </ReactFlow>

      <div className="fixed bottom-[max(16px,env(safe-area-inset-bottom))] left-4 z-30 flex flex-col items-start gap-4">
        <div className="flex items-center gap-3">
          <button onClick={goHome} className="silver-btn h-14 rounded-full px-6 font-hand text-[26px]" aria-label={TEXT.home}>✦ {TEXT.home}</button>
          <button onClick={() => setPanel("credits")} className="silver-btn h-12 rounded-full px-4 text-[15px] opacity-70">{TEXT.credits}</button>
        </div>
        <div className="pointer-events-none flex items-center gap-3 pl-1 opacity-85">
          {LOGOS.map((l, i) => (
            <div key={l.src} className="flex items-center gap-3">
              {i > 0 && <span className="h-8 w-px bg-silver-line/40" aria-hidden />}
              <img src={l.src} alt={l.alt} draggable={false} className="h-12 w-12 object-contain" />
            </div>
          ))}
        </div>
      </div>
      <h1 className="sr-only">{APP_TITLE}</h1>

      {introDone && showPrompt && (
        <div className="prompt hand pointer-events-none fixed inset-x-4 top-[max(28px,env(safe-area-inset-top))] z-20 text-center text-[30px] sm:text-[36px]">
          {TEXT.zoomPrompt}
        </div>
      )}
      {toast && <div className="hand fixed left-1/2 top-8 z-50 -translate-x-1/2 rounded-full bg-panel/90 px-6 py-2 text-[26px]">{toast}</div>}

      {card && (
        <DetailPanel
          card={card}
          onClose={() => setOpenCard(null)}
          onGoTo={(id) => { setOpenCard(null); goToCard(id); }}
        />
      )}
      {panel === "credits" && <CreditsPanel onClose={() => setPanel(null)} />}
      {panel === "notes" && <NoteComposer onClose={() => setPanel(null)} onSubmit={addNote} />}
      {!introDone && <Intro onDone={finishIntro} />}
    </BoardCtx.Provider>
  );
}

export default function App() {
  return (
    <ReactFlowProvider>
      <Board />
    </ReactFlowProvider>
  );
}
