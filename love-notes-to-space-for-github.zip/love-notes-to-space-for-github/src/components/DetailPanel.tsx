import { useRef, useState, type ReactNode } from "react";
import { TEXT } from "../data/board";
import type { Card } from "../data/types";
import { connectedTo, has } from "../lib/content";
import { GlowStar, RoughQuote } from "./Rough";
import SmartImg from "./SmartImg";

// Frosted-glass sheet: slides up from the bottom on iPad, centred on big screens.
// Tap outside or swipe down to close.
export function Sheet({ onClose, children, label }: { onClose: () => void; children: ReactNode; label: string }) {
  const panel = useRef<HTMLDivElement>(null);
  const drag = useRef<{ y: number; dy: number } | null>(null);
  const [dy, setDy] = useState(0);
  return (
    <div className="fixed inset-0 z-40 flex items-end justify-center bg-black/45 lg:items-center" onClick={onClose}>
      <div
        ref={panel}
        role="dialog"
        aria-label={label}
        className="sheet relative max-h-[88vh] w-full overflow-y-auto overscroll-contain rounded-t-[28px] px-6 pb-10 pt-4 sm:px-10 lg:max-h-[86vh] lg:max-w-[780px] lg:rounded-[28px]"
        style={{ transform: dy ? `translateY(${dy}px)` : undefined, transition: drag.current ? "none" : undefined }}
        onClick={(e) => e.stopPropagation()}
        onTouchStart={(e) => { if (panel.current!.scrollTop <= 0) drag.current = { y: e.touches[0].clientY, dy: 0 }; }}
        onTouchMove={(e) => {
          if (!drag.current) return;
          const d = e.touches[0].clientY - drag.current.y;
          drag.current.dy = d; setDy(Math.max(0, d));
        }}
        onTouchEnd={() => { const d = drag.current?.dy ?? 0; drag.current = null; setDy(0); if (d > 110) onClose(); }}
      >
        <div className="mx-auto mb-4 h-1.5 w-14 rounded-full bg-silver-mid/60 lg:hidden" />
        <button onClick={onClose} aria-label={TEXT.close} className="silver-btn absolute right-4 top-4 z-10 h-12 w-12 rounded-full text-2xl">×</button>
        {children}
      </div>
    </div>
  );
}

const Section = ({ heading, text }: { heading: string; text?: string }) =>
  has(text) ? (
    <section className="mt-8">
      <h3 className="hand text-[30px] text-teal">{heading}</h3>
      <p className="body-text mt-1">{text}</p>
    </section>
  ) : null;

function Gallery({ card }: { card: Card }) {
  const [i, setI] = useState(0);
  if (card.video)
    return (
      <div className="silver-frame"><div className="frame-inner aspect-video">
        <video src={card.video} autoPlay muted loop playsInline className="h-full w-full object-cover" onError={(e) => ((e.currentTarget.style.display = "none"))} />
      </div></div>
    );
  if (!card.images.length)
    return <div className="silver-frame"><div className="frame-inner aspect-[16/9]"><GlowStar size={110} /></div></div>;
  return (
    <div>
      <div
        className="flex snap-x snap-mandatory gap-4 overflow-x-auto pb-1 [scrollbar-width:none]"
        onScroll={(e) => setI(Math.round(e.currentTarget.scrollLeft / e.currentTarget.clientWidth))}
      >
        {card.images.map((img, k) => (
          <figure key={img.file + k} className="w-full shrink-0 snap-center">
            <div className="silver-frame"><div className="frame-inner max-h-[48vh]">
              <SmartImg file={img.file} size="full" eager={k === 0} className="max-h-[48vh] w-full object-contain" />
            </div></div>
            {has(img.credit) && <figcaption className="mt-2 text-[16px] text-silver-soft">{img.credit}</figcaption>}
          </figure>
        ))}
      </div>
      {card.images.length > 1 && (
        <div className="mt-3 flex justify-center gap-2" aria-hidden>
          {card.images.map((_, k) => <span key={k} className={`h-2 w-2 rounded-full ${k === i ? "bg-teal" : "bg-silver-mid/50"}`} />)}
        </div>
      )}
    </div>
  );
}

export default function DetailPanel({ card, onClose, onGoTo }: { card: Card; onClose: () => void; onGoTo: (id: string) => void }) {
  const links = connectedTo(card.id);
  return (
    <Sheet onClose={onClose} label={card.title}>
      <div className="pt-8">
        <Gallery key={card.id} card={card} />
        <h2 className="hand mt-6 text-[48px] leading-tight">{card.title}</h2>
        {has(card.sourceCredit) && <p className="mt-1 text-[18px] font-medium text-teal-light">{card.sourceCredit}</p>}
        <Section heading={TEXT.whatItIs} text={card.whatItIs} />
        {has(card.myThought) && (
          <section className="mt-8 flex gap-4">
            <div className="pt-1"><RoughQuote /></div>
            <div>
              <p className="text-[21px] leading-[1.6] text-warm">{card.myThought}</p>
              <p className="hand mt-2 text-[28px] text-warm">{TEXT.signature}</p>
            </div>
          </section>
        )}
        <Section heading={TEXT.starThread} text={card.starThread} />
        <Section heading={TEXT.backToEarth} text={card.backToEarth} />
        {links.length > 0 && (
          <section className="mt-8">
            <h3 className="hand text-[30px] text-teal">{TEXT.connectedTo}</h3>
            <div className="mt-3 flex flex-wrap gap-3">
              {links.map((c) => (
                <button key={c.id} onClick={() => onGoTo(c.id)} className="silver-btn rounded-full px-5 py-3 text-[18px]">
                  {c.title}
                </button>
              ))}
            </div>
          </section>
        )}
      </div>
    </Sheet>
  );
}
