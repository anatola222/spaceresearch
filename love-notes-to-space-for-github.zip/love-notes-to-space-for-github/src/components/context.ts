import { createContext } from "react";

export type ActiveEdge = { id: string; x: number; y: number } | null;

export const BoardCtx = createContext<{
  revealed: boolean;
  activeEdge: ActiveEdge;
  openNotes: () => void;
  clearNotes: () => void;
}>({ revealed: true, activeEdge: null, openNotes: () => {}, clearNotes: () => {} });
