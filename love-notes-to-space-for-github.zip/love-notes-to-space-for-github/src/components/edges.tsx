import { memo, useContext } from "react";
import { BaseEdge, EdgeLabelRenderer, useInternalNode, type Edge, type EdgeProps, type InternalNode } from "@xyflow/react";
import type { EdgeData } from "../lib/layout";
import { BoardCtx } from "./context";

const box = (n: InternalNode) => {
  const w = n.measured.width ?? 0, h = n.measured.height ?? 0;
  const p = n.internals.positionAbsolute;
  return { cx: p.x + w / 2, cy: p.y + h / 2, w, h };
};

// Point where the line from a box's centre towards (tx, ty) leaves the box.
const edgeOf = (b: ReturnType<typeof box>, tx: number, ty: number, pad = 0) => {
  const dx = tx - b.cx, dy = ty - b.cy;
  const s = Math.min((b.w / 2 + pad) / Math.abs(dx || 1e-6), (b.h / 2 + pad) / Math.abs(dy || 1e-6), 1);
  return [b.cx + dx * s, b.cy + dy * s] as const;
};

const useEnds = (source: string, target: string, pad = 0) => {
  const s = useInternalNode(source), t = useInternalNode(target);
  if (!s || !t || !s.measured.width || !t.measured.width) return null;
  const a = box(s), b = box(t);
  const [x1, y1] = edgeOf(a, b.cx, b.cy, pad);
  const [x2, y2] = edgeOf(b, a.cx, a.cy, pad);
  return { x1, y1, x2, y2 };
};

const StarDot = ({ x, y }: { x: number; y: number }) => (
  <g pointerEvents="none">
    <circle cx={x} cy={y} r={7} fill="#5FE3D0" opacity={0.28} />
    <circle cx={x} cy={y} r={2.6} fill="#E6FFFB" />
  </g>
);

// Card-to-card line: fine silver thread with a star at each end. Tap to read why.
export const ConstellationEdge = memo(({ id, source, target, data }: EdgeProps<Edge<EdgeData>>) => {
  const { activeEdge } = useContext(BoardCtx);
  const e = useEnds(source, target, 6);
  if (!e) return null;
  const d = `M${e.x1},${e.y1} L${e.x2},${e.y2}`;
  const active = activeEdge?.id === id;
  return (
    <>
      <g className={data?.pulse ? "edge-pulse" : undefined}>
        <path d={d} stroke="#5FE3D0" strokeOpacity={data?.pulse ? 0.35 : 0.1} strokeWidth={data?.pulse ? 7 : 5} fill="none" pointerEvents="none" />
        <BaseEdge
          path={d}
          interactionWidth={30}
          style={{ stroke: data?.pulse ? "#9AF5E8" : active ? "#E8E8EE" : "#C9CAD6", strokeOpacity: active ? 1 : 0.6, strokeWidth: active ? 2 : 1 }}
        />
        <StarDot x={e.x1} y={e.y1} />
        <StarDot x={e.x2} y={e.y2} />
      </g>
      {active && data?.why && (
        <EdgeLabelRenderer>
          <div
            className="edge-caption hand pointer-events-none absolute max-w-[340px] rounded-2xl px-5 py-3 text-center text-[26px] leading-snug"
            style={{ transform: `translate(-50%, calc(-100% - 18px)) translate(${activeEdge!.x}px, ${activeEdge!.y}px)` }}
          >
            {data.why}
          </div>
        </EdgeLabelRenderer>
      )}
    </>
  );
});

// Constellation label to the film: one faint dashed line per constellation.
export const ClusterLinkEdge = memo(({ source, target }: EdgeProps) => {
  const e = useEnds(source, target, 14);
  if (!e) return null;
  return (
    <path
      d={`M${e.x1},${e.y1} L${e.x2},${e.y2}`}
      stroke="#C9CAD6" strokeOpacity={0.22} strokeWidth={1.2} strokeDasharray="3 12" fill="none" pointerEvents="none"
    />
  );
});

export const edgeTypes = { constellation: ConstellationEdge, clusterLink: ClusterLinkEdge };
