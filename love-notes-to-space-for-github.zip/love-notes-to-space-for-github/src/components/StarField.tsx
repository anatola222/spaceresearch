// The night sky: nebula + three parallax star layers on one canvas behind the board.
import { useEffect, useRef } from "react";
import { useStoreApi } from "@xyflow/react";
import { rng } from "../lib/random";

type Star = { u: number; v: number; r: number; a: number; color: string; tw: number; ph: number };
const LAYERS = [
  { density: 1 / 2600, parallax: 0.03, rMax: 0.9 },
  { density: 1 / 5200, parallax: 0.08, rMax: 1.4 },
  { density: 1 / 14000, parallax: 0.16, rMax: 2.1 },
];
const BLOBS = [
  { color: "59,31,94", x: 0.25, y: 0.3, r: 0.55, sp: 0.00011 },
  { color: "42,20,64", x: 0.75, y: 0.65, r: 0.6, sp: 0.00008 },
  { color: "59,31,94", x: 0.6, y: 0.15, r: 0.4, sp: 0.00014 },
  { color: "74,36,110", x: 0.15, y: 0.85, r: 0.45, sp: 0.0001 },
];
const mod = (a: number, n: number) => ((a % n) + n) % n;

export default function StarField() {
  const ref = useRef<HTMLCanvasElement>(null);
  const store = useStoreApi();

  useEffect(() => {
    const canvas = ref.current!;
    const ctx = canvas.getContext("2d")!;
    const neb = document.createElement("canvas");
    const nctx = neb.getContext("2d")!;
    let W = 0, H = 0, layers: Star[][] = [], raf = 0;

    const resize = () => {
      const dpr = Math.min(devicePixelRatio || 1, 1.5);
      W = innerWidth; H = innerHeight;
      canvas.width = W * dpr; canvas.height = H * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      neb.width = Math.ceil(W / 8); neb.height = Math.ceil(H / 8);
      const r = rng(7);
      layers = LAYERS.map((L) =>
        Array.from({ length: Math.round(W * H * L.density) }, () => ({
          u: r(), v: r(), r: 0.3 + r() * L.rMax, a: 0.35 + r() * 0.65,
          color: r() < 0.55 ? "#5FE3D0" : "#9AF5E8",
          tw: r() < 0.14 ? 3000 + r() * 3000 : 0, ph: r() * Math.PI * 2,
        })),
      );
    };

    const draw = (t: number) => {
      raf = requestAnimationFrame(draw);
      if (document.hidden) return;
      const [tx, ty, zoom] = store.getState().transform;

      // nebula, drawn small and scaled up so it stays soft and cheap
      const nw = neb.width, nh = neb.height;
      nctx.fillStyle = "#150B26"; nctx.fillRect(0, 0, nw, nh);
      for (const b of BLOBS) {
        const x = (b.x + 0.08 * Math.sin(t * b.sp)) * nw + (tx * 0.01) / 8;
        const y = (b.y + 0.06 * Math.cos(t * b.sp * 1.3)) * nh + (ty * 0.01) / 8;
        const g = nctx.createRadialGradient(x, y, 0, x, y, b.r * Math.max(nw, nh));
        g.addColorStop(0, `rgba(${b.color},0.85)`); g.addColorStop(1, `rgba(${b.color},0)`);
        nctx.fillStyle = g; nctx.fillRect(0, 0, nw, nh);
      }
      ctx.imageSmoothingEnabled = true;
      ctx.drawImage(neb, 0, 0, W, H);

      // stars: deeper layers move less; everything wraps so the sky never runs out
      LAYERS.forEach((L, li) => {
        const s = Math.pow(zoom, L.parallax * 2.5);
        const ox = tx * L.parallax, oy = ty * L.parallax;
        for (const st of layers[li]) {
          const x = mod(W / 2 + (st.u * W - W / 2) * s + ox, W);
          const y = mod(H / 2 + (st.v * H - H / 2) * s + oy, H);
          const a = st.tw ? st.a * (0.3 + 0.7 * (0.5 + 0.5 * Math.sin((t / st.tw) * Math.PI * 2 + st.ph))) : st.a;
          ctx.globalAlpha = a; ctx.fillStyle = st.color;
          const r = st.r * Math.min(1.6, Math.max(0.8, s));
          if (r < 1) ctx.fillRect(x, y, r * 1.6, r * 1.6);
          else { ctx.beginPath(); ctx.arc(x, y, r, 0, 6.283); ctx.fill(); }
        }
      });
      ctx.globalAlpha = 1;
    };

    resize();
    addEventListener("resize", resize);
    raf = requestAnimationFrame(draw);
    return () => { cancelAnimationFrame(raf); removeEventListener("resize", resize); };
  }, [store]);

  return <canvas ref={ref} className="fixed inset-0 h-full w-full" aria-hidden />;
}
