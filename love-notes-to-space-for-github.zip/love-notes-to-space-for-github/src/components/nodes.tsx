import { memo, useContext, useRef, useState, type CSSProperties } from "react";
import { Handle, Position, type Node, type NodeProps } from "@xyflow/react";
import { TEXT } from "../data/board";
import { has } from "../lib/content";
import { CARD_H, CARD_W, FILM_H, FILM_W, type CardData, type DoodleData, type FilmData, type FrameData, type LabelData } from "../lib/layout";
import { BoardCtx } from "./context";
import { Doodle, GlowStar, RoughArrow, RoughCircle, RoughUnderline } from "./Rough";
import SmartImg from "./SmartImg";

// Invisible handles: lines are drawn centre-to-centre by the custom edges.
const Handles = () => (
  <>
    <Handle type="source" position={Position.Top} className="!opacity-0 !pointer-events-none" isConnectable={false} />
    <Handle type="target" position={Position.Top} className="!opacity-0 !pointer-events-none" isConnectable={false} />
  </>
);

const useReveal = (delay: number): CSSProperties => {
  const { revealed } = useContext(BoardCtx);
  return revealed ? { animation: `reveal 1100ms ease-out ${delay}ms both` } : { opacity: 0 };
};

const SmallStar = ({ size = 22 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden className="shrink-0 drop-shadow-[0_0_6px_#5FE3D0]">
    <path d="M12 1 L14.5 9.5 L23 12 L14.5 14.5 L12 23 L9.5 14.5 L1 12 L9.5 9.5 Z" fill="#5FE3D0" />
  </svg>
);

export const CardNode = memo(({ data }: NodeProps<Node<CardData>>) => {
  const { card, rotation, revealDelay } = data;
  const style = useReveal(revealDelay);
  const stack = Math.min(2, card.images.length - 1);
  return (
    <div className="card-node relative" style={{ width: CARD_W, height: CARD_H, ...style }}>
      <Handles />
      <div className="relative h-full w-full" style={{ transform: `rotate(${rotation}deg)` }}>
        {stack >= 2 && <div className="silver-frame absolute inset-0" style={{ transform: "rotate(5deg) translate(12px,-9px)" }} />}
        {stack >= 1 && <div className="silver-frame absolute inset-0" style={{ transform: "rotate(-4deg) translate(-10px,-6px)" }} />}
        <div className="silver-frame glow relative h-full w-full">
          <div className="frame-inner">
            {card.images[0] ? <SmartImg file={card.images[0].file} size="thumb" className="h-full w-full object-cover" /> : <GlowStar />}
          </div>
        </div>
      </div>
      <div className="hand absolute left-1/2 top-full mt-3 w-[320px] -translate-x-1/2 text-center text-[28px] leading-tight">{card.title}</div>
      {has(card.annotation) && (
        <div className="pointer-events-none absolute" style={{ left: -170, top: -150, width: 190, height: 150 }}>
          <div className="hand absolute left-0 top-0 -rotate-6 whitespace-nowrap text-[26px] text-teal-light">{card.annotation}</div>
          <div className="absolute" style={{ left: 70, top: 40 }}>
            <RoughArrow w={105} h={95} seed={card.id.length} />
          </div>
        </div>
      )}
    </div>
  );
});

export const FilmNode = memo(({ data }: NodeProps<Node<FilmData>>) => {
  const [failed, setFailed] = useState(false);
  return (
    <div className="card-node relative" style={{ width: FILM_W, height: FILM_H }}>
      <Handles />
      <div className="silver-frame glow film h-full w-full">
        <div className="frame-inner">
          {data.card.video && !failed ? (
            <video src={data.card.video} autoPlay muted loop playsInline preload="auto" onError={() => setFailed(true)} className="h-full w-full object-cover" />
          ) : (
            <GlowStar size={130} />
          )}
        </div>
      </div>
      <div className="hand absolute left-1/2 top-full mt-3 w-[400px] -translate-x-1/2 text-center text-[36px]">{data.card.title}</div>
    </div>
  );
});

export const LabelNode = memo(({ data }: NodeProps<Node<LabelData>>) => {
  const style = useReveal(data.revealDelay);
  const w = data.cluster.label.length * 19 + 50;
  return (
    <div className="flex cursor-pointer flex-col items-center px-4 py-2" style={style}>
      <Handles />
      <div className="flex items-center gap-2">
        <SmallStar />
        <span className="hand whitespace-nowrap text-[46px] leading-none">{data.cluster.label}</span>
      </div>
      <RoughUnderline width={w} seed={w} />
    </div>
  );
});

export const FrameNode = memo(({ data }: NodeProps<Node<FrameData>>) => {
  const style = useReveal(data.revealDelay);
  return (
    <div style={style}>
      <RoughCircle size={data.radius * 2} seed={data.seed} />
    </div>
  );
});

export const DoodleNode = memo(({ data }: NodeProps<Node<DoodleData>>) => {
  const style = useReveal(data.revealDelay + 400);
  return (
    <div style={style}>
      <Doodle kind={data.kind} seed={data.seed} />
    </div>
  );
});

// "Write a love note…": tap to write; hold for 5 seconds to clear all notes (for staff).
export const NotesNode = memo(({ data }: NodeProps<Node<{ revealDelay: number }>>) => {
  const style = useReveal(data.revealDelay);
  const { openNotes, clearNotes } = useContext(BoardCtx);
  const timer = useRef<number>();
  const start = useRef<{ x: number; y: number } | null>(null);
  const held = useRef(false);
  const cancel = () => { clearTimeout(timer.current); start.current = null; };
  return (
    <div
      className="flex max-w-[520px] cursor-pointer flex-col items-center px-6 py-4 text-center"
      style={style}
      onPointerDown={(e) => {
        held.current = false; start.current = { x: e.clientX, y: e.clientY };
        timer.current = window.setTimeout(() => { held.current = true; clearNotes(); }, 5000);
      }}
      onPointerMove={(e) => { if (start.current && Math.hypot(e.clientX - start.current.x, e.clientY - start.current.y) > 12) cancel(); }}
      onPointerUp={cancel}
      onPointerCancel={cancel}
      onClick={() => { if (held.current) { held.current = false; return; } openNotes(); }}
      onContextMenu={(e) => e.preventDefault()}
    >
      <SmallStar size={30} />
      <span className="hand mt-2 text-[44px] leading-tight">{TEXT.notesTitle}</span>
      <span className="mt-3 rounded-full border border-silver-line/60 px-5 py-2 font-hand text-[26px] text-teal-light">✎ ✦</span>
    </div>
  );
});

export const VisitorNoteNode = memo(({ data }: NodeProps<Node<{ text: string; delay: number }>>) => (
  <div className="visitor-note flex max-w-[280px] items-start gap-2" style={{ animationDelay: `${data.delay}ms` }}>
    <SmallStar size={16} />
    <span className="hand text-[24px] leading-snug">{data.text}</span>
  </div>
));

export const nodeTypes = {
  card: CardNode,
  film: FilmNode,
  label: LabelNode,
  frame: FrameNode,
  doodle: DoodleNode,
  notes: NotesNode,
  visitorNote: VisitorNoteNode,
};
