import { useState } from "react";
import { imageSources } from "../lib/images";
import { GlowStar } from "./Rough";

// Tries the small web copy first, then the original; shows a glowing star if nothing loads.
export default function SmartImg({ file, size, className = "", eager = false }: { file: string; size: "thumb" | "full"; className?: string; eager?: boolean }) {
  const sources = imageSources(file, size);
  const [i, setI] = useState(0);
  if (i >= sources.length)
    return (
      <div className={`flex h-full w-full items-center justify-center bg-[#1b1030] ${className}`}>
        <GlowStar />
      </div>
    );
  return (
    <img
      src={sources[i]}
      alt=""
      draggable={false}
      loading={eager ? "eager" : "lazy"}
      decoding="async"
      onError={() => setI(i + 1)}
      className={className}
    />
  );
}
