// Hand-drawn marks (rough.js), rendered as plain SVG paths.
import { memo, useMemo } from "react";
import rough from "roughjs";
import type { Drawable, Options } from "roughjs/bin/core";

const gen = rough.generator();
const CHALK = "#F4F0FA";

const Paths = ({ drawables }: { drawables: Drawable[] }) => (
  <>
    {drawables.flatMap((d, i) =>
      gen.toPaths(d).map((p, j) => (
        <path key={`${i}-${j}`} d={p.d} stroke={p.stroke} strokeWidth={p.strokeWidth} fill={p.fill ?? "none"} strokeLinecap="round" />
      )),
    )}
  </>
);

const opts = (o: Options): Options => ({ stroke: CHALK, strokeWidth: 1.6, roughness: 1.4, bowing: 1.2, ...o });

export const RoughCircle = memo(({ size, seed, opacity = 0.22 }: { size: number; seed: number; opacity?: number }) => {
  const d = useMemo(() => [gen.ellipse(size / 2, size / 2, size * 0.98, size * 0.94, opts({ seed, roughness: 2.2, strokeWidth: 2 }))], [size, seed]);
  return (
    <svg width={size} height={size} style={{ overflow: "visible", opacity }} aria-hidden>
      <Paths drawables={d} />
    </svg>
  );
});

export const RoughUnderline = memo(({ width, seed }: { width: number; seed: number }) => {
  const d = useMemo(() => [gen.curve([[4, 8], [width * 0.45, 3], [width - 4, 7]], opts({ seed, stroke: "#5FE3D0", strokeWidth: 2 }))], [width, seed]);
  return (
    <svg width={width} height={14} style={{ overflow: "visible" }} aria-hidden>
      <Paths drawables={d} />
    </svg>
  );
});

// Curved arrow from the note (top-left of the box) down to the target (bottom-right).
export const RoughArrow = memo(({ w, h, seed }: { w: number; h: number; seed: number }) => {
  const d = useMemo(() => {
    const [x1, y1, x2, y2] = [6, 6, w - 6, h - 6];
    const ang = Math.atan2(y2 - (y1 + h * 0.5), x2 - (x1 + w * 0.55));
    const head = (da: number): [number, number] => [x2 - 16 * Math.cos(ang + da), y2 - 16 * Math.sin(ang + da)];
    return [
      gen.curve([[x1, y1], [x1 + w * 0.55, y1 + h * 0.5], [x2, y2]], opts({ seed, strokeWidth: 2.2 })),
      gen.linearPath([head(0.45), [x2, y2], head(-0.45)], opts({ seed: seed + 1, strokeWidth: 2.2 })),
    ];
  }, [w, h, seed]);
  return (
    <svg width={w} height={h} style={{ overflow: "visible" }} aria-hidden>
      <Paths drawables={d} />
    </svg>
  );
});

export const Doodle = memo(({ kind, seed }: { kind: "star" | "heart" | "question"; seed: number }) => {
  const d = useMemo(() => {
    const o = opts({ seed, strokeWidth: 2, stroke: kind === "heart" ? "#FFB8C8" : kind === "star" ? "#9AF5E8" : CHALK });
    if (kind === "star") {
      const pts: [number, number][] = [];
      for (let i = 0; i <= 10; i++) {
        const r = i % 2 ? 9 : 22, a = -Math.PI / 2 + (i * Math.PI) / 5;
        pts.push([25 + r * Math.cos(a), 25 + r * Math.sin(a)]);
      }
      return [gen.linearPath(pts, o)];
    }
    if (kind === "heart") return [gen.path("M25 44 C4 30 2 12 14 8 C21 6 25 12 25 16 C25 12 29 6 36 8 C48 12 46 30 25 44 Z", o)];
    return [gen.path("M15 16 C15 4 37 4 36 16 C35 25 25 25 25 33", o), gen.circle(25, 43, 3, { ...o, fill: CHALK, fillStyle: "solid" })];
  }, [kind, seed]);
  return (
    <svg width={50} height={50} style={{ overflow: "visible", opacity: 0.75 }} aria-hidden>
      <Paths drawables={d} />
    </svg>
  );
});

export const RoughQuote = memo(({ seed = 5 }: { seed?: number }) => {
  const d = useMemo(() => {
    const o = opts({ seed, stroke: "#5FE3D0", strokeWidth: 2.4, roughness: 1 });
    const mark = (x: number) => [
      gen.circle(x + 8, 12, 12, { ...o, fill: "#5FE3D0", fillStyle: "solid" }),
      gen.curve([[x + 13, 14], [x + 10, 26], [x + 1, 32]], o),
    ];
    return [...mark(2), ...mark(22)];
  }, [seed]);
  return (
    <svg width={46} height={38} style={{ overflow: "visible" }} aria-hidden>
      <Paths drawables={d} />
    </svg>
  );
});

// Softly glowing teal star, used when a card has no image.
export const GlowStar = ({ size = 72 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 100 100" className="glow-star" aria-hidden>
    <defs>
      <radialGradient id="gs-halo">
        <stop offset="0" stopColor="#9AF5E8" stopOpacity=".55" />
        <stop offset="1" stopColor="#5FE3D0" stopOpacity="0" />
      </radialGradient>
    </defs>
    <circle cx="50" cy="50" r="48" fill="url(#gs-halo)" />
    <path d="M50 14 L57 43 L86 50 L57 57 L50 86 L43 57 L14 50 L43 43 Z" fill="#E6FFFB" />
  </svg>
);
