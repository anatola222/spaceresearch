import { useEffect, useState } from "react";
import { NOTES, TEXT } from "../data/board";
import { credits } from "../lib/content";
import { Sheet } from "./DetailPanel";

export function CreditsPanel({ onClose }: { onClose: () => void }) {
  return (
    <Sheet onClose={onClose} label={TEXT.creditsTitle}>
      <h2 className="hand pt-8 text-[44px]">{TEXT.creditsTitle}</h2>
      <ul className="mt-4 space-y-4">
        {credits.map((c) => (
          <li key={c.credit} className="body-text">
            <span className="font-medium text-chalk">{c.credit}</span>
            <span className="text-silver-soft">: {c.titles.join(", ")}</span>
          </li>
        ))}
      </ul>
    </Sheet>
  );
}

export function NoteComposer({ onClose, onSubmit }: { onClose: () => void; onSubmit: (text: string) => void }) {
  const [text, setText] = useState("");
  return (
    <Sheet onClose={onClose} label={TEXT.notesTitle}>
      <form
        className="pt-8"
        onSubmit={(e) => { e.preventDefault(); if (text.trim()) onSubmit(text.trim()); }}
      >
        <h2 className="hand text-[40px] leading-tight">{TEXT.notesTitle}</h2>
        <textarea
          autoFocus
          value={text}
          maxLength={NOTES.maxLength}
          onChange={(e) => setText(e.target.value)}
          placeholder={TEXT.notesPlaceholder}
          rows={4}
          className="mt-5 w-full resize-none rounded-2xl border border-silver-line/50 bg-cosmos/70 p-5 font-hand text-[30px] leading-snug text-chalk placeholder:text-silver-mid focus:border-teal focus:outline-none"
        />
        <div className="mt-1 text-right text-[16px] text-silver-soft">{text.length} / {NOTES.maxLength}</div>
        <button type="submit" disabled={!text.trim()} className="silver-btn mt-4 w-full rounded-full px-6 py-4 font-hand text-[30px] disabled:opacity-40">
          {TEXT.notesSubmit}
        </button>
      </form>
    </Sheet>
  );
}

// The opening line, fading in word by word.
export function Intro({ onDone }: { onDone: () => void }) {
  const words = TEXT.introLine.split(" ");
  const [leaving, setLeaving] = useState(false);
  useEffect(() => {
    const total = words.length * 380 + 2600;
    const a = setTimeout(() => setLeaving(true), total);
    const b = setTimeout(onDone, total + 1200);
    return () => { clearTimeout(a); clearTimeout(b); };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <div
      className={`fixed inset-0 z-50 flex items-center justify-center bg-cosmos/80 px-8 transition-opacity duration-[1200ms] ${leaving ? "opacity-0" : ""}`}
      onClick={() => { setLeaving(true); setTimeout(onDone, 600); }}
    >
      <p className="hand max-w-[900px] text-center text-[44px] leading-snug sm:text-[64px]">
        {words.map((w, i) => (
          <span key={i} className="intro-word" style={{ animationDelay: `${i * 380}ms` }}>{w} </span>
        ))}
      </p>
    </div>
  );
}
