/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        cosmos: "#150B26",
        violet: "#3B1F5E",
        plum: "#2A1440",
        panel: "#1E1235",
        teal: { DEFAULT: "#5FE3D0", light: "#9AF5E8" },
        chalk: "#F4F0FA",
        ink: "#EDE9F5",
        warm: "#FFF6EC",
        silver: { light: "#E8E8EE", mid: "#A9ABB8", soft: "#D8D9E2", line: "#C9CAD6" },
      },
      fontFamily: {
        hand: ['"Caveat"', "cursive"],
        body: ['"Inter"', "system-ui", "sans-serif"],
      },
    },
  },
  plugins: [],
};
